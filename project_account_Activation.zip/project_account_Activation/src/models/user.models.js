const mongoose = require('mongoose')
const userSchema = mongoose.Schema({
    firstname:{
        type:String
    },
    lastname:{
        type:String
    },
    username:{
        type:String
    },
    email:{
        type:String
    },
    password:{
        type:String
    },
    mobile:{
        type:String
    },
  
    
    isActive:{
        type:Boolean,
        default:false
    }
})
module.exports = mongoose.model('companies',userSchema)