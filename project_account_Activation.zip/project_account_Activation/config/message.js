const {body} = require('express-validator')

module.exports = {
    ACCOUNT_ACTIVATION:"One confirmation has been send to your email id so need check your mail and click confirm to your account activation",
    TOKEN_EXPIRED:"token is expired or may be incorrect",
    ACCOUNT_SUCCESSFUL:"your account has been activated succesfully",
    RESET_PASSWORD:"Password has been changed or reset",
    TOKEN_SUCCESS:"Token has been generated successfully",
    EMAIL_VALIDATION: body('email').isEmail().normalizeEmail().withMessage('Please enter valid email address'),
    PASSWORD_VALIDATION: body('password').isStrongPassword({
        minLength:8,
        minUppercase:1,
        minLowercase:1,
        minSymbols:1,
        minNumbers:1
    }).withMessage("Please enter a password at least 8 character and contain At least one uppercase.At least one lower case.At least one special character."),
    REQUIRED_FILLED_VALIDATION:body('password').notEmpty().withMessage("Password is required"),
    NEW_PASSWORD_VALIDATION: body('newPassword').isStrongPassword({
        minLength:8,
        minUppercase:1,
        minLowercase:1,
        minSymbols:1,
        minNumbers:1
    }).withMessage("Please enter a password at least 8 character and contain At least one uppercase.At least one lower case.At least one special character.")
}