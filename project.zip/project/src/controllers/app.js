router.post('/forgetPassword',async (req,res)=>{
    const {email, password} = req.body;
    const user = await userSignUp.findOne({email:email})
    if(!user){res.status(400).json({message:"not a valid user"})}
    else{
        //create token    
        const token = jwt.sign({email:req.body.email},
            process.env.TOKEN_KEY,
            {expiresIn:"10m"});
            userSignUp.token = token;
            res.json({token,message:"token created"})

            const transporter = nodemailer.createTransport({
                host:'smtp.gmail.com',
                secure:false,
                requireTLS:true,                
                auth:{
                    user:"nitishchauhan19999@gmail.com",
                    pass:"NChauhan@1992"
                }
            })
            const link = `http://localhost:3000/api/updatePassword/${user.email}/${token}`
            console.log(link)
            const maildata = {
                from:'nitishchauhan19999@gmail.com',
                to:'nitishchauhan19999@gmail.com',
                subject:"account activation",
                text:link
            }
            transporter.sendMail(maildata,(err,info)=>{
                if(err) {
                    console.log("mail not send")
                }
                else{
                    console.log("mail send")
                }
            })
    }
       
})
