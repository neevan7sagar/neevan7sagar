const express = require('express')
const router = express.Router();
const bodyParser = require('body-parser')
router.use(bodyParser.json())
const Messages = require('../../config/message')
const usercontrollers = require('../controllers/user.controllers')
const usermiddlewares = require('../middlewares/user.middleware')
//Routers
router.post('/signup' ,Messages.EMAIL_VALIDATION,Messages.PASSWORD_VALIDATION,usermiddlewares.validate,usercontrollers.usersignup)
router.get('/useracountactivation/:token',usercontrollers.useracount_activation)
router.post('/login',Messages.EMAIL_VALIDATION,Messages.REQUIRED_FILLED_VALIDATION,usermiddlewares.validate,usercontrollers.userlogin)
router.post('/refreshtoken',usercontrollers.refreshToken)
router.get('/users',usermiddlewares.chektoken,usercontrollers.getAllUser)
router.post('/forgetpassword',Messages.EMAIL_VALIDATION,Messages.PASSWORD_VALIDATION,usermiddlewares.validate,usercontrollers.forgetpassword)
router.post('/resetpassword/:token',Messages.NEW_PASSWORD_VALIDATION,usermiddlewares.validate,usercontrollers.resetpassword)
module.exports = router
