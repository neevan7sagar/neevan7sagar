const express = require('express')
const app = express();
const ejs=require("ejs");
const path  = require('path')
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const userRoute = require('./src/routes/user.routes')
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}))
const userController = require('./src/controllers/user.controllers')
const auth = require('./src/middlewares/user.middleware')
const  db = require('./config/database');
const logger = require('./config/logger');
// signup view engine
app.set('view engine','ejs')
app.set('views', path.join(__dirname, 'views'));
mongoose.connect(db.url,{
    useNewUrlParser:true,
    useUnifiedTopology:true
}).then(()=>{
    console.log("Database connected successfully")
}).catch(err=>{
    console.log(err)
})
//app.use(auth.chektoken)
app.use('/', userRoute)


//file render
app.post('/welcome',(req,res)=>{
    let email = req.body.email
    res.render('welcome', {email:email} )
})

app.get('/login',(req,res)=>{
    res.render('login')
})
app.get('/signup',(req,res)=>{
    res.render('signup')
})
app.get('/forgetpassword',(req,res)=>{
    res.render('forgetpassword')
})
app.get('/resetpassword/:token',(req,res)=>{
    res.render('resetpassword',{token:req.params.token})
})



const port = process.env.port || 3000
app.listen(port,()=>{
    // console.log(`server is running on port ${port}`)
    logger.info(`server is running on port ${port}`)
    console.log(__dirname)
})